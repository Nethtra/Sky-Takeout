self.__precacheManifest = [
  {
    "revision": "24013d487a0256c7f73c",
    "url": "css/404.6a750851.css"
  },
  {
    "revision": "24013d487a0256c7f73c",
    "url": "js/404.c61770cf.js"
  },
  {
    "revision": "51e829e56f213b57ca76",
    "url": "css/app.fd9b670b.css"
  },
  {
    "revision": "51e829e56f213b57ca76",
    "url": "js/app.d0aa4eb3.js"
  },
  {
    "revision": "7a3a7e33ab783cefaec7",
    "url": "css/chunk-vendors.37cc3fbd.css"
  },
  {
    "revision": "7a3a7e33ab783cefaec7",
    "url": "js/chunk-vendors.9b7e46a0.js"
  },
  {
    "revision": "355a63bba4e9f571e50b",
    "url": "css/dashboard.8da8967e.css"
  },
  {
    "revision": "355a63bba4e9f571e50b",
    "url": "js/dashboard.630a609e.js"
  },
  {
    "revision": "d9b8ea589fcb23371fb5",
    "url": "css/login.f8377ced.css"
  },
  {
    "revision": "d9b8ea589fcb23371fb5",
    "url": "js/login.90288d75.js"
  },
  {
    "revision": "6701dd7c295485717209",
    "url": "css/shopTable.5fd29e98.css"
  },
  {
    "revision": "6701dd7c295485717209",
    "url": "js/shopTable.fe534d8f.js"
  },
  {
    "revision": "0f4bc32b0f52f7cfb7d19305a6517724",
    "url": "img/404-cloud.0f4bc32b.png"
  },
  {
    "revision": "89ccbe0c2d72c31965177702b8819493",
    "url": "img/noImg.89ccbe0c.png"
  },
  {
    "revision": "e769fc3e331db6393679005e3c9b43fd",
    "url": "img/search_table_empty.e769fc3e.png"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "885371bc928de5c918d64e713802eaba",
    "url": "img/table_empty.885371bc.png"
  },
  {
    "revision": "a57b6f31fa77c50f14d756711dea4158",
    "url": "img/404.a57b6f31.png"
  },
  {
    "revision": "38b01728209c82713206be752ed54b3a",
    "url": "img/icon_logo.38b01728.png"
  },
  {
    "revision": "6ef9d2601d2ec762577f90aa72ad97aa",
    "url": "img/login-l.6ef9d260.png"
  },
  {
    "revision": "3f1fe127c88eefb495aeccb83e0fdbe8",
    "url": "media/preview.3f1fe127.mp3"
  },
  {
    "revision": "38b01728209c82713206be752ed54b3a",
    "url": "img/logo.38b01728.png"
  },
  {
    "revision": "bf141cfc2896c5eda967747dcee92776",
    "url": "img/mini-logo.bf141cfc.png"
  },
  {
    "revision": "0a3849af76d2bea914a0df06aa75d892",
    "url": "media/reminder.0a3849af.mp3"
  },
  {
    "revision": "1a82643b8f1ab45ccdc52c0a678dc975",
    "url": "index.html"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  }
];